<?php
            session_start();
                if($_SESSION['username']==""){
                    header("location:login.php?pemberitahuan=gagal");
                }
                ?>
<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>PERMOHONAN</title>

    <!-- Custom fonts for this template-->
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link
        href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i"
        rel="stylesheet">

    <!-- Custom styles for this template-->
    <link href="css/sb-admin-2.min.css" rel="stylesheet">

     <!-- Custom styles for this page -->
    <link href="vendor/datatables/dataTables.bootstrap4.min.css" rel="stylesheet">

</head>

<body id="page-top">

    <!-- Page Wrapper -->
    <div id="wrapper">

        <!-- Sidebar -->
        <ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">

            <!-- Sidebar - Brand
            <a class="sidebar-brand d-flex align-items-center justify-content-center" href="halaman_utama.php">
                <div class="sidebar-brand-icon rotate-n-15">
                    <i class="fas fa-laugh-wink"></i>
                </div>
                <div class="sidebar-brand-text mx-3">Admin PARC </div>
            </a>
        -->

        <a class="sidebar-brand d-flex align-items-center justify-content-center" href="#">
            
            <img class="img-profile rounded-circle" style="width: 40px; height: 40px;" src="img/parc2.jpeg">
        
        <div class="sidebar-brand-text mx-3"> <i class="fa fa-circle" style=" color: #5cb85c; font-size: 15px;margin-right: 4px;"> online</i> </div>
         
    </a>


            

            <!-- Divider -->
            <hr class="sidebar-divider my-0">

            <!-- Nav Item - Dashboard -->
            <li class="nav-item">
                <a class="nav-link" href="halaman_utama.php">
                    <i class="fas fa-fw fa-tachometer-alt"></i>
                    <span>Dashboard</span></a>
            </li>

            <!-- Divider -->
            <hr class="sidebar-divider my-0">

            <li class="nav-item active">
                <a class="nav-link" href="permohonan.php">
                    <i class="fa fa-user-edit" aria-hidden="true"></i>
                    <span>Permohonan</span></a>
            </li>
            
            <hr class="sidebar-divider my-0">

            <li class="nav-item">
                <a class="nav-link" href="maklumat_pelajar.php">
                    <i class="fa fa-user-shield" aria-hidden="true"></i>
                    <span>Maklumat Pelajar</span></a>
            </li>

            <hr class="sidebar-divider my-0">

            <li class="nav-item">
                <a class="nav-link" href="u&p.php">
                    <i class="fa fa-key" aria-hidden="true"></i>
                    <span>Username & Password</span></a>
            </li>

            <hr class="sidebar-divider my-0">

            <li class="nav-item">
                <a class="nav-link" href="https://accounts.google.com/ServiceLogin/signinchooser?service=mail&passive=true&rm=false&continue=https%3A%2F%2Fmail.google.com%2Fmail%2F&ss=1&scc=1&ltmpl=default&ltmplcache=2&emr=1&osid=1&flowName=GlifWebSignIn&flowEntry=ServiceLogin" 
                target="_blank">
                    <i class="fa fa-envelope-open-text" aria-hidden="true"></i>
                    <span>E-mail</span></a>
                </li>

                <hr class="sidebar-divider my-0">

            <li class="nav-item">
                <a class="nav-link" href="logout.php">
                    <i class="fas fa-power-off" aria-hidden="true"></i>
                    <span>Logout</span></a>
            </li>

            <hr class="sidebar-divider my-0">

            <!-- Divider -->
            <hr class="sidebar-divider d-none d-md-block">

            <!-- Sidebar Toggler (Sidebar) -->
            <div class="text-center d-none d-md-inline">
                <button class="rounded-circle border-0" id="sidebarToggle"></button>
            </div>


            <!-- Sidebar Message 
            <div class="sidebar-card">
                <img class="sidebar-card-illustration mb-2" src="img/undraw_rocket.svg" alt="">
                <p class="text-center mb-2"><strong>SB Admin Pro</strong> is packed with premium features, components, and more!</p>
                <a class="btn btn-success btn-sm" href="https://startbootstrap.com/theme/sb-admin-pro">Upgrade to Pro!</a>
            </div>
        -->

        </ul>
        <!-- End of Sidebar -->

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">

                

                <!-- Topbar -->
                <nav class="navbar navbar-expand topbar mb-4 static-top shadow" style="background-color: gray;">


                    <!--imej PARC dalam top bar-->
                    <div class="container">
                        <img style="width: 100px; height: 50px;" src="img/linux.jpeg" >
                    
                        <img style="width: 100px; height: 50px;" src="img/parc3.jpeg">

                        <img style="width: 100px; height: 50px;" src="img/parc1.jpg">
                </div>

                </nav>

                

        <!-- Begin Page Content -->
        <div class="container-fluid">

            <!-- Page Heading 
            <h1 class="h3 mb-2 text-gray-800">Tables</h1>
            <p class="mb-4">DataTables is a third party plugin that is used to generate the demo table below.
                For more information about DataTables, please visit the <a target="_blank"
                    href="https://datatables.net">official DataTables documentation</a>.</p>
            -->

            <!-- DataTales Example -->
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">Permohonan Penyertaan PARC</h6>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                            <thead>
                                <tr>
                                <th style="text-align:center;">Bil</th>
                                <th style="text-align:center;">Daftar</th>
                                <th style="text-align:center;">Nama</th>
                                <th style="text-align:center;">Umur</th>
                                <th style="text-align:center;">Nombor Telefon</th>
                                <th style="text-align:center;">Model Laptop</th>
                                <th style="text-align:center;">Proccessor</th>
                                <th style="text-align:center;">RAM</th>
                                <th style="text-align:center;">Kursus</th>
                                <th style="text-align:center;">Hari</th>
                                <th style="text-align:center;">Masa</th>
                                <th style="text-align:center;">Tarikh Permohonan</th>
                                <th style="text-align:center;">Status</th>
                                <th style="text-align:center;">Rayuan</th>
                                <th style="text-align:center;">Tindakan</th>
                                </tr>
                            </thead>
                            <?php 
                                include 'connection.php';
                                $sql = "SELECT * FROM permohonan";
                                $res = mysqli_query($conn,$sql);
                                $bil=1;
                                while($row=mysqli_fetch_assoc($res)){
                                    $id = $row['id'];
                                    $nama = $row['nama'];
                                    $umur = $row['umur'];
                                    $telefon = $row['telefon'];
                                    $model_laptop = $row['model_laptop'];
                                    $pro = $row['pro'];
                                    $ram = $row['ram'];
                                    $kursus = $row['kursus'];
                                    $hari = $row['hari'];
                                    $masa = $row['masa'];
                                    $rayuan = $row['rayuan'];
                                    $sql2 = "SELECT * FROM permohonan where id='$id' LIMIT 1";
                                    $res2 = mysqli_query($conn,$sql2);
                                    $row2=mysqli_fetch_assoc($res2);
                                    if($row2['status'] == '0'){ // status pending
                                        $status = "Sedang Diproses";
                                        $bg = "#1976D2";
                                        $color = "#fff";
                                    }
                                    if($row2['status'] == '1'){// status Terima
                                        $status = "Terima";
                                        $bg = "#4CAF50";
                                        $color = "#fff";
                                    }
                                    if($row2['status'] == '2'){// status Penolakkan
                                        $status = "Gagal";
                                        $bg = "#D32F2F";
                                        $color = "#fff";
                                    }
                                    if($row['status'] == '3'){// status Penolakkan
                                        $status = "Dikeluarkan";
                                        $bg = "#000000";
                                        $color = "#fff";
                                    }

                            ?>
                                
                                <tr>
                                <td style="text-align:center;"><?php echo $bil++;?></td>
                                <td style="text-align:center;"><?php echo "$id";?></td>
                                <td style="text-align:center;"><?php echo "$nama";?></td>
                                <td style="text-align:center;"><?php echo "$umur";?></td>
                                <td style="text-align:center;"><?php echo "$telefon";?></td>
                                <td style="text-align:center;"><?php echo "$model_laptop";?></td>
                                <td style="text-align:center;"><?php echo "$pro";?></td>
                                <td style="text-align:center;"><?php echo "$ram";?></td>
                                <td style="text-align:center;"><?php echo "$kursus";?></td>
                                <td style="text-align:center;"><?php echo "$hari";?></td>
                                <td style="text-align:center;"><?php echo "$masa";?></td>
                                <td style="text-align:center;"><?php echo date('d-m-y h:i:sa', strtotime($row['tarikh_permohonan'])); ?></td>
                                <td style="text-align:center;"><span class="badge" style="background:<?php echo "$bg";?>;color:<?php echo "$color";?>;"><?php echo "$status";?></span></td>
                                <td style="text-align:center;"><?php echo "$rayuan";?></td>
                                <td style="text-align:center;">
                                    <?php if($row2['status'] == 0) { // hanya pending sahaja?>
                                    <span class="icon-block"><a href="edit_permohonan.php?id=<?php echo $id;?>"><i style="color:#388E3C;" class="fa fa-check"></i></span>
                                    <?php } ?>
                                    <span class="icon-block"><a href="profile.php?id=<?php echo $id;?>"><i class="fa fa-edit"></i></a></span>
                                    <a  href="padam.php?id=<?php echo $row['id']; ?>" class="btn-del"><i class="fa fa-trash-alt"></i></a></td>
                                    
                                </td>
                                </tr>
                                <?php 
                                }
                                
                                ?>
                        </table>
                    </div>
                </div>
            </div>

        </div>
        <!-- /.container-fluid -->

    </div>
    <!-- End of Main Content -->

    <!-- Footer -->
    <footer class="sticky-footer bg-white">
        <div class="container my-auto">
            <div class="copyright text-center my-auto">
                <span>Copyright &copy; ZULKIFLI 2021</span>
            </div>
        </div>
    </footer>
    </div>
</div>
    <!-- End of Footer -->
                

    <!-- Bootstrap core JavaScript-->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Core plugin JavaScript-->
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

    <!-- Custom scripts for all pages-->
    <script src="js/sb-admin-2.min.js"></script>

     <!-- Page level plugins -->
     <script src="vendor/datatables/jquery.dataTables.min.js"></script>
     <script src="vendor/datatables/dataTables.bootstrap4.min.js"></script>

    <!-- Page level custom scripts -->
    <script src="js/demo/datatables-demo.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@10"></script>
    <script>
    $('.btn-del').on('click',function(e){
        e.preventDefault();
        const href=$(this).attr('href')
            Swal.fire({
              icon : 'warning',
              title : 'Anda Pasti??',
              text : 'Padam Permohonan Ini?',
              type : 'warning',
              showCancelButton : true,
              confirmButtonColor : '#3085d6',
              cancelButtonColor : '#d33',
              confirmButtonText : 'Ya',
              cancelButtonText : 'Batal'
              }).then((result)=>{
        if (result.value){
            document.location.href = href;
            }
          })
        })
          $('#btn').on('click',function(){
            Swal.fire({
              type : 'success',
              title : 'Berjaya!!',
              text : 'Rekod Permohonan Telah Dipadamkan.'
              })
            })
        const flashdata = $('.flash-data').data('flashdata')
        if (flashdata){
              Swal.fire({
                icon : 'success',
                type : 'success',
                title : 'Berjaya!!',
                text : 'Rekod Permohonan Telah Dipadamkan!'
            })
          }
  </script>
 
</body>
</html>