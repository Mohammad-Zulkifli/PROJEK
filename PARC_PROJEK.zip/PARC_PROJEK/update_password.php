<?php 
include 'connection.php';
 
$id = $_POST['id'];
$password = md5($_POST['password']); 

$query = "update user set password='$password' where id='$id'";

$result = mysqli_query($conn,$query);

if($result){
	echo "<script type='text/javascript'>
	      setTimeout(function () { 
	        Swal.fire({
	        		icon: 'success',
	        		type: 'success',
	                title: 'Tahniah!!',
	                text: 'Kata Laluan Berjaya Dikemaskini.',
	                timer: 3200,
	                showConfirmButton: true
	            });   
	      },10);  
	      window.setTimeout(function(){ 
	        window.location.replace('u&p.php');
	      } ,3000); 
	      </script>";
}else{
	echo "Kemaskini Gagal!";

}
?>
<script src="js/jquery-3.4.1.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@10"></script>