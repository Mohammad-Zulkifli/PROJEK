<!doctype html>
<html lang="en">
  <head>
    <title> Tentang Kami</title>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
  </head>
  <body background="img/parc1.jpg" style="background-repeat: no-repeat; background-attachment: fixed; background-size: 100%;">
        <nav class="navbar navbar-expand-sm navbar-light bg-light">
            <button class="navbar-toggler d-lg-none" type="button" data-toggle="collapse" data-target="#collapsibleNavId" aria-controls="collapsibleNavId"
                aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="collapsibleNavId">
                <ul class="navbar-nav mr-auto mt-2 mt-lg-0">
                    <li class="nav-item">
                        <a class="nav-link" href="index.php">Home</a>
                    </li>
                    <li class="nav-item active">
                        <a class="nav-link" href="tentangkami.php"> Tentang Kami </a>
                    </li>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="dropdownId" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Program Yang Ditawarkan</a>
                        <div class="dropdown-menu" aria-labelledby="dropdownId">
                            <a class="dropdown-item" href="asaslinux.php">Asas Linux</a>
                            <a class="dropdown-item" href="programming.php">Programming dan Database</a>
                            <a class="dropdown-item" href="net.php">Networking</a>
                        </div>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="pendaftaran.php"> Pendaftaran Baru </a>
                    </li>
                </ul>
                <form class="form-inline my-2 my-lg-0">
                    <a class="btn btn-outline-success my-2 my-sm-0" type="button" href="login.php"> LOGIN </a>
                </form>
            </div>
        </nav>
        <br>
        <div class="container">
            <h5 style="text-align: center;color: aqua;">SELAMAT DATANG KE WEBSITE PENDAFTARAN PARC</h5>
            <br>
            <br>
            <p style="color: green; text-align: justify;"><b>  1.  Apa itu PARC, Bila PARC ditubuhkan, Dapat sambutan ke PARC ni ?</b></p>
            <br>
            <br>
            <p style="text-align: justify;"> <mark style="color: dark"> <b>PARC</b> ialah akronim untuk <b>‘Putera Army Rileks Community’</b>  yang merupakan komuniti teknologi maklumat yang didirikan pada tahun <b>2001</b>  yang mengumpulkan anak-anak muda dan pelajar daripada seluruh Malaysia dengan bakat tersembunyi di dalam bidang teknologi maklumat khusus dalam skop rangkaian dan sekuriti alam maya.</mark> </p>
            <p style="color: yellow; text-align: justify;"><mark style="color: dark">Komuniti ini didirikan pada <b>2001</b>  yang mana pada asalnya hanya sebuah forum yang dipanggil <b>RC.my atau RIleks Community</b> . Pada 2015, komuniti PARC mengendalikan kelas secara tersendiri untuk masyarakat. Kelas ini diajar oleh 5 orang tenaga pengajar dengan berlatarbelakangkan dan berpendidikan sains komputer dan teknologi maklumat menggunakan pelbagai perisian seperti Skype sebagai medium perantaraan dan Microsoft Word sebagai medium untuk tenaga pengajar mengedarkan nota dan soalan ujian kepada peserta.</mark></p>
            <p style="color: yellow; text-align: justify;"><mark style="color: dark">Kelas ini <b>mendapat respon sebanyak 500 peserta</b>  yang berminat dengan pelbagai latar belakang yang ingin menyertai kelas ini. Daripada jumlah peserta yang berminat tersebut, <b> 200 peserta</b> dipilih untuk menyertai sesi kelas tersebut. PARC juga mengendalikan ujian untuk menguji kefahaman para peserta berdasarkan silibus kelas yang telah dipelajari. Sepanjang sesi kelas, <b>tiada cas yang dikenakan kepada para peserta</b> .</mask></p>
        </div>
        
      
    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
  </body>
</html>