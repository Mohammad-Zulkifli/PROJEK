<?php 
include 'connection.php';
 
// menangkap data yang di kirim dari form
$id = $_POST['id'];
$umur = $_POST['umur']; 
$nama = $_POST['nama']; 
$telefon = $_POST['telefon']; 
$model_laptop = $_POST['model_laptop']; 
$pro = $_POST['pro']; 
$ram = $_POST['ram']; 
// update data ke database
$query = "UPDATE permohonan set umur='$umur',nama='$nama',telefon='$telefon',model_laptop='$model_laptop',pro='$pro',ram='$ram' where id='$id'";

$result = mysqli_query($conn,$query);

if($result){
	echo "<script type='text/javascript'>
	      setTimeout(function () { 
	        Swal.fire({
	        		icon: 'success',
	        		type: 'success',
	                title: 'Tahniah!!',
	                text: 'Maklumat Berjaya Dikemaskini.',
	                timer: 3200,
	                showConfirmButton: true
	            });   
	      },10);  
	      window.setTimeout(function(){ 
	        window.location.replace('maklumat_pemohon.php');
	      } ,3000); 
	      </script>";
}else{
	echo "Kemaskini Gagal!";

}
?>
<script src="js/jquery-3.4.1.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@10"></script>