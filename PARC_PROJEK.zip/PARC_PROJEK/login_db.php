<?php
// session start php
session_start();
 
include 'connection.php';
 
$username = $_POST['username'];
$password = md5($_POST['password']);

$q = mysqli_query($conn,"SELECT * FROM user WHERE username='$username' and password='$password'");
$r = mysqli_fetch_array ($q);
$q2 = mysqli_query($conn,"SELECT * FROM admin WHERE username='$username' and password='$password'");
$row = mysqli_fetch_array ($q2);

if (mysqli_num_rows($q) == 1) {
	echo "<script type='text/javascript'>
        setTimeout(function () { 
          Swal.fire({
              icon: 'success',
              type: 'success',
                  title: 'Selamat Datang Ke Sistem Pendaftaran PARC!!',
                  text: 'Anda Telah Berjaya Log Masuk.',
                  timer: 3200,
                  showConfirmButton: true
              });   
        },10);  
        window.setTimeout(function(){ 
          window.location.replace('halaman_pelajar.php');
        } ,3000); 
        </script>";
    $_SESSION['id'] = $r['id'];
    $_SESSION['username'] = $r['username'];
    $_SESSION['password'] = $r['password'];
    $_SESSION['level'] = 'pelajar';
    
}
elseif (mysqli_num_rows($q2) == 1) {
	echo"<script type='text/javascript'>
        setTimeout(function () { 
          Swal.fire({
              icon: 'success',
              type: 'success',
                  title: 'Selamat Datang Ke Sistem Pendaftaran PARC!!',
                  text: 'Anda Telah Berjaya Log Masuk.',
                  timer: 3200,
                  showConfirmButton: true
              });   
        },10);  
        window.setTimeout(function(){ 
          window.location.replace('halaman_utama.php');
        } ,3000); 
        </script>";
    $_SESSION['id'] = $row['id'];
    $_SESSION['username'] = $row['username'];
    $_SESSION['password'] = $row['password'];
    $_SESSION['level'] = 'admin';
    
}else {
    header("location:login.php?pemberitahuan=gagal");
}
?>

 <script src="js/jquery-3.4.1.min.js"></script>
 <script src="https://cdn.jsdelivr.net/npm/sweetalert2@10"></script>