<!-- status login -->
<?php
            session_start();
                if($_SESSION['username']==""){
                    header("location:login.php?pemberitahuan=gagal");
                }
                ?>
<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>HALAMAN ADMIN</title>

    <!-- Custom fonts for this template-->
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link
        href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i"
        rel="stylesheet">

    <!-- Custom styles for this template-->
    <link href="css/sb-admin-2.min.css" rel="stylesheet">

</head>

<body id="page-top">

    <!-- Page Wrapper -->
    <div id="wrapper">

        <!-- Sidebar -->
        <ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">

            <!-- Sidebar - Brand
            <a class="sidebar-brand d-flex align-items-center justify-content-center" href="halaman_utama.php">
                <div class="sidebar-brand-icon rotate-n-15">
                    <i class="fas fa-laugh-wink"></i>
                </div>
                <div class="sidebar-brand-text mx-3">Admin PARC </div>
            </a>
        -->

        <a class="sidebar-brand d-flex align-items-center justify-content-center" href="#">
            
            <img class="img-profile rounded-circle" style="width: 40px; height: 40px; " src="img/parc2.jpeg">
        
        <div class="sidebar-brand-text mx-3"> <i class="fa fa-circle" style=" color: #5cb85c; font-size: 15px;margin-right: 4px;"> online</i> </div>
         
    </a>

            <!-- Divider -->
            <hr class="sidebar-divider my-0">

            <!-- Nav Item - Dashboard -->
            <li class="nav-item active">
                <a class="nav-link" href="halaman_utama.php">
                    <i class="fas fa-fw fa-tachometer-alt"></i>
                    <span>Dashboard</span></a>
            </li>

            <!-- Divider -->
            <hr class="sidebar-divider my-0">

            <li class="nav-item">
                <a class="nav-link" href="permohonan.php">
                    <i class="fa fa-user-edit" aria-hidden="true"></i>
                    <span>Permohonan</span></a>
            </li>
            
            <hr class="sidebar-divider my-0">

            <li class="nav-item">
                <a class="nav-link" href="maklumat_pelajar.php">
                    <i class="fa fa-user-shield" aria-hidden="true"></i>
                    <span>Maklumat Pelajar</span></a>
            </li>

            <hr class="sidebar-divider my-0">

            <li class="nav-item">
                <a class="nav-link" href="u&p.php">
                    <i class="fa fa-key" aria-hidden="true"></i>
                    <span>Username & Password</span></a>
                </li>

            <hr class="sidebar-divider my-0">

            <li class="nav-item">
                <a class="nav-link" href="https://accounts.google.com/ServiceLogin/signinchooser?service=mail&passive=true&rm=false&continue=https%3A%2F%2Fmail.google.com%2Fmail%2F&ss=1&scc=1&ltmpl=default&ltmplcache=2&emr=1&osid=1&flowName=GlifWebSignIn&flowEntry=ServiceLogin" 
                target="_blank">
                    <i class="fa fa-envelope-open-text" aria-hidden="true"></i>
                    <span>E-mail</span></a>
                </li>

                <hr class="sidebar-divider my-0">

            <li class="nav-item">
                <a class="nav-link" href="logout.php">
                    <i class="fas fa-power-off" aria-hidden="true"></i>
                    <span>Logout</span></a>
            </li>

            <hr class="sidebar-divider my-0">

            <!-- Divider -->
            <hr class="sidebar-divider d-none d-md-block">

            <!-- Sidebar Toggler (Sidebar) -->
            <div class="text-center d-none d-md-inline">
                <button class="rounded-circle border-0" id="sidebarToggle"></button>
            </div>


            <!-- Sidebar Message 
            <div class="sidebar-card">
                <img class="sidebar-card-illustration mb-2" src="img/undraw_rocket.svg" alt="">
                <p class="text-center mb-2"><strong>SB Admin Pro</strong> is packed with premium features, components, and more!</p>
                <a class="btn btn-success btn-sm" href="https://startbootstrap.com/theme/sb-admin-pro">Upgrade to Pro!</a>
            </div>
        -->

        </ul>
        <!-- End of Sidebar -->

         <!-- Content Wrapper -->
         <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">

                 <!-- Topbar -->
                 <nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">


                    <!-- Topbar welcome -->
                    <form> 
                    <marquee direction="left" scrollamount="15">
                    <span class="font-weight-bold text-dark badge-success">
                         HAI, SELAMAT DATANG KE SISTEM PENDAFTARAN PUTERA ARMY RILEKS CREW. <img style="width:12%; " src="img/parc3.jpeg"> 
                    </span>  </marquee>
                    </form>

                    <!-- Topbar Navbar -->
                    <ul class="navbar-nav ml-auto">

                        <div class="topbar-divider d-none d-sm-block"></div>
                        
                        <!-- Nav Item - User Information -->
                        <li class="nav-item dropdown no-arrow">
                            <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button">
                            <div class="sidebar-brand-text mx-3"><span class="font-weight-bold text-dark"><strong><?php echo $_SESSION['username']; ?></strong> </span></div>                
                              
                                <img class="img-profile rounded-circle"
                                    src="img/undraw_profile.svg">
                            </a>
                        </li>

                    </ul>

                </nav>
            <!-- End of Topbar -->

             <!-- Begin Page Content -->
                 <div class="container-fluid">

             <!-- Page Heading -->
                    <div class="d-sm-flex align-items-center justify-content-between mb-4">
                        <!--<h1 class="h3 mb-0 text-gray-800">Dashboard</h1>-->
                    </div>
                </div>

            <!--card content for dashboard-->
            <div class="container">
                <div>
                    <h3 style="text-align: center; color: blue;">Jadual Waktu Kelas Linux</h3>
                </div>
                    <br>
                <br>
                <div class="card-deck">
                    <div class="card" style="border-color: rgb(255, 0, 255); border-width: 5px; border-style: inset;">
                          <img class="card-img-top" src="img/linux.jpeg" alt="Card image cap">
                          <div class="card-body">
                            <h5 class="card-title" style="text-align: center;">DELL & AMD</h5>
                            <br>
                            <p class="card-text" style="text-align: center;">Waktu kelas 11.00 - 1.00 PM (SABTU & AHAD)</p>
                            <br>
                            <br>
                            <p class="card-text" style="text-align: center; font-family: Georgia, 'Times New Roman', Times, serif;"><small class="text-muted"><b>PENGAJAR : Cikgu Arif</b></small></p>
                          </div>
                        </div>
                    <div class="card" style="border-color: rgb(0, 0, 255); border-width: 5px; border-style: inset;">
                        <img class="card-img-top" src="img/linux.jpeg" alt="Card image cap">
                        <div class="card-body">
                            <h5 class="card-title" style="text-align: center;">MINT & ARCH</h5>
                            <br>
                            <p class="card-text" style="text-align: center;">Waktu kelas 8.00 - 10.00 PM (KHAMIS & JUMAAT)</p>
                            <br>
                            <br>
                            <p class="card-text" style="text-align: center; font-family: Georgia, 'Times New Roman', Times, serif;"><small class="text-muted"><b>PENGAJAR : Cikgu Fathurrahman</b></small></p>
                          </div>
                        </div>
                    <div class="card" style="border-color: rgb(0, 255, 0); border-width: 5px; border-style: inset;">
                        <img class="card-img-top" src="img/linux.jpeg" alt="Card image cap">
                        <div class="card-body">
                            <h5 class="card-title" style="text-align: center;"> REDHAT </h5>
                            <br>
                            <p class="card-text" style="text-align: center;">Waktu kelas 3.00 - 4.00 PM (SABTU)</p>
                            <br>
                            <br>
                            <p class="card-text" style="text-align: center; font-family: Georgia, 'Times New Roman', Times, serif;"><small class="text-muted"><b>PENGAJAR : Cikgu Hafizurrahman</b></small></p>
                          </div>
                        </div>
                        <div class="card" style="border-color: red; border-width: 5px; border-style: inset;">
                            <img class="card-img-top" src="img/linux.jpeg" alt="Card image cap">
                            <div class="card-body">
                                <h5 class="card-title" style="text-align: center;"> NETGEAR </h5>
                                <br>
                                <p class="card-text" style="text-align: center;">Waktu kelas 9.00 - 11.00 PM (JUMAAT)</p>
                                <br>
                                <br>
                                <p class="card-text" style="text-align: center; font-family: Georgia, 'Times New Roman', Times, serif;"><small class="text-muted"><b>PENGAJAR : Cikgu Fazri</b></small></p>
                              </div>
                            </div>
                    </div>
                </div>
                <br>
                <!--card content for dashboard-->
            <div class="container">
                <div class="card-deck">
                    <div class="card" style="border-color: rgb(255, 0, 255); border-width: 5px; border-style: inset;">
                          <img class="card-img-top" src="img/linux.jpeg" alt="Card image cap">
                          <div class="card-body">
                            <h5 class="card-title" style="text-align: center;">HUAWEI</h5>
                            <br>
                            <p class="card-text" style="text-align: center;">Waktu kelas 8.00 - 10.00 PM (JUMAAT)</p>
                            <br>
                            <br>
                            <p class="card-text" style="text-align: center; font-family: Georgia, 'Times New Roman', Times, serif;"><small class="text-muted"><b>PENGAJAR : Cikgu Faizal</b></small></p>
                          </div>
                        </div>
                    <div class="card" style="border-color: rgb(0, 0, 255); border-width: 5px; border-style: inset;">
                        <img class="card-img-top" src="img/linux.jpeg" alt="Card image cap">
                        <div class="card-body">
                            <h5 class="card-title" style="text-align: center;">CENTOS</h5>
                            <br>
                            <p class="card-text" style="text-align: center;">Waktu kelas 3.00 - 4.00 PM (AHAD)</p>
                            <br>
                            <br>
                            <p class="card-text" style="text-align: center; font-family: Georgia, 'Times New Roman', Times, serif;"><small class="text-muted"><b>PENGAJAR : Cikgu Syafiyullah</b></small></p>
                          </div>
                        </div>
                    <div class="card" style="border-color: rgb(0, 255, 0); border-width: 5px; border-style: inset;">
                        <img class="card-img-top" src="img/linux.jpeg" alt="Card image cap">
                        <div class="card-body">
                            <h5 class="card-title" style="text-align: center;"> CPU </h5>
                            <br>
                            <p class="card-text" style="text-align: center;">Waktu kelas 8.00 - 10.00 PM (JUMAAT)</p>
                            <br>
                            <br>
                            <p class="card-text" style="text-align: center; font-family: Georgia, 'Times New Roman', Times, serif;"><small class="text-muted"><b>PENGAJAR : Cikgu Saiful Suffian</b></small></p>
                          </div>
                        </div>
                        <div class="card" style="border-color: red; border-width: 5px; border-style: inset;">
                            <img class="card-img-top" src="img/linux.jpeg" alt="Card image cap">
                            <div class="card-body">
                                <h5 class="card-title" style="text-align: center;"> CORSAIR & RAZER </h5>
                                <br>
                                <p class="card-text" style="text-align: center;">Waktu kelas 8.00 - 10.00 PM (JUMAAT & SABTU)</p>
                                <br>
                                <br>
                                <p class="card-text" style="text-align: center; font-family: Georgia, 'Times New Roman', Times, serif;"><small class="text-muted"><b>PENGAJAR : Cikgu Tholhah</b></small></p>
                              </div>
                            </div>
                    </div>
                </div>

                <br>
            <br>

            <!--card content for dashboard-->
            <div class="container">
                <div>
                    <h3 style="text-align: center; color: blue;">Jadual Waktu Kelas Programming & Database</h3>
                </div>
                    <br>
                <br>
                <div class="card-deck">
                    <div class="card" style="border-color: rgb(255, 0, 255); border-width: 5px; border-style: inset;">
                          <img class="card-img-top" src="img/parc.jpg" alt="Card image cap">
                          <div class="card-body">
                            <h5 class="card-title" style="text-align: center;">BIT | BYTE | KILOBYTE</h5>
                            <br>
                            <p class="card-text" style="text-align: center;">Waktu kelas 8.30 - 10.00 PM</p>
                            <br>
                            <br>
                            <p class="card-text" style="text-align: center; font-family: Georgia, 'Times New Roman', Times, serif;"><small class="text-muted"><b>PENGAJAR : Cikgu Fakhruddin</b></small></p>
                          </div>
                        </div>
                    <div class="card" style="border-color: rgb(0, 0, 255); border-width: 5px; border-style: inset;">
                        <img class="card-img-top" src="img/parc.jpg" alt="Card image cap">
                        <div class="card-body">
                            <h5 class="card-title" style="text-align: center;">EXABYTE | TERABYTE & MEGABYTE | GIGABYTE</h5>
                            <p class="card-text" style="text-align: center;">Waktu kelas 10.00 - 11.30 AM & 8.30 - 10.00 PM</p>
                            <br>
                            <p class="card-text" style="text-align: center; font-family: Georgia, 'Times New Roman', Times, serif;"><small class="text-muted"><b>PENGAJAR : Cikgu Zahir & Amin</b></small></p>
                          </div>
                        </div>
                    <div class="card" style="border-color: rgb(0, 255, 0); border-width: 5px; border-style: inset;">
                        <img class="card-img-top" src="img/parc.jpg" alt="Card image cap">
                        <div class="card-body">
                            <h5 class="card-title" style="text-align: center;"> ZETTABYTE </h5>
                            <br>
                            <p class="card-text" style="text-align: center;">Waktu kelas 10.00 - 11.30 AM</p>
                            <br>
                            <br>
                            <p class="card-text" style="text-align: center; font-family: Georgia, 'Times New Roman', Times, serif;"><small class="text-muted"><b>PENGAJAR : Cikgu Rafieq</b></small></p>
                          </div>
                        </div>
                    </div>
                </div>

                <br>
            <br>
            
                <!--card content for dashboard-->
            <div class="container">
                <div>
                    <h3 style="text-align: center; color: blue;">Jadual Waktu Kelas Networking</h3>
                </div>
                    <br>
                <br>
                <div class="card-deck">
                    <div class="card" style="border-color: rgb(255, 0, 255); border-width: 5px; border-style: inset;">
                          <img class="card-img-top" src="img/linux.jpeg" alt="Card image cap">
                          <div class="card-body">
                            <h5 class="card-title" style="text-align: center;"> <b>NO DATA</b>  </h5>
                            <br>
                            <p class="card-text" style="text-align: center;"><b>NO DATA</b></p>
                            <br>
                            <br>
                            <p class="card-text" style="text-align: center; font-family: Georgia, 'Times New Roman', Times, serif;"><small class="text-muted"><b><b>NO DATA</b></b></small></p>
                          </div>
                        </div>
                    <div class="card" style="border-color: rgb(0, 0, 255); border-width: 5px; border-style: inset;">
                        <img class="card-img-top" src="img/linux.jpeg" alt="Card image cap">
                        <div class="card-body">
                            <h5 class="card-title" style="text-align: center;"><b>NO DATA</b></h5>
                            <br>
                            <p class="card-text" style="text-align: center;"><b>NO DATA</b></p>
                            <br>
                            <br>
                            <p class="card-text" style="text-align: center; font-family: Georgia, 'Times New Roman', Times, serif;"><small class="text-muted"><b><b>NO DATA</b></b></small></p>
                          </div>
                        </div>
                    <div class="card" style="border-color: rgb(0, 255, 0); border-width: 5px; border-style: inset;">
                        <img class="card-img-top" src="img/linux.jpeg" alt="Card image cap">
                        <div class="card-body">
                            <h5 class="card-title" style="text-align: center;"> <b>NO DATA</b> </h5>
                            <br>
                            <p class="card-text" style="text-align: center;"><b>NO DATA</b></p>
                            <br>
                            <br>
                            <p class="card-text" style="text-align: center; font-family: Georgia, 'Times New Roman', Times, serif;"><small class="text-muted"><b><b>NO DATA</b></b></small></p>
                          </div>
                        </div>
                    </div>
                </div>
            </div>   

                <br>
            <br>

    <!-- Footer -->
    <footer class="sticky-footer bg-white">
        <div class="container my-auto">
            <div class="copyright text-center my-auto">
                <span>Copyright &copy; ZULKIFLI 2021</span>
            </div>
        </div>
    </footer>
    </div>
</div>
    <!-- End of Footer -->
                

    <!-- Bootstrap core JavaScript-->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Core plugin JavaScript-->
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

    <!-- Custom scripts for all pages-->
    <script src="js/sb-admin-2.min.js"></script>

    <!-- Page level plugins -->
    <script src="vendor/chart.js/Chart.min.js"></script>

    <!-- Page level custom scripts -->
    <script src="js/demo/chart-area-demo.js"></script>
    <script src="js/demo/chart-pie-demo.js"></script>

     <!-- Page level plugins -->
     <script src="vendor/datatables/jquery.dataTables.min.js"></script>
     <script src="vendor/datatables/dataTables.bootstrap4.min.js"></script>

    <!-- Page level custom scripts -->
    <script src="js/demo/datatables-demo.js"></script>

</body>

</html>