<?php 
include 'connection.php';
 
$id = $_POST['id'];
$status = $_POST['status'];
 
$query = "update permohonan set status='$status' where id='$id'";

$result = mysqli_query($conn,$query);

if($result){
	echo "<script type='text/javascript'>
	      setTimeout(function () { 
	        Swal.fire({
	        		icon: 'success',
	        		type: 'success',
	                title: 'Tahniah!!',
	                text: 'Data Berjaya Dikemaskini.',
	                timer: 3200,
	                showConfirmButton: true
	            });   
	      },10);  
	      window.setTimeout(function(){ 
	        window.location.replace('permohonan.php');
	      } ,3000); 
	      </script>";
}else{
	echo "Kemaskini Gagal!";

}
?>
<script src="js/jquery-3.4.1.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@10"></script>