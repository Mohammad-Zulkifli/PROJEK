<!doctype html>
<html lang="en">
  <head>
    <title> Asas Programming dan Database</title>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
  </head>
  <body background="img/black.jpg" style="background-repeat: no-repeat; background-attachment: fixed; background-size: 100%;">
        <nav class="navbar navbar-expand-sm navbar-light bg-light">
            <button class="navbar-toggler d-lg-none" type="button" data-toggle="collapse" data-target="#collapsibleNavId" aria-controls="collapsibleNavId"
                aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="collapsibleNavId">
                <ul class="navbar-nav mr-auto mt-2 mt-lg-0">
                    <li class="nav-item">
                        <a class="nav-link" href="index.php">Home</a>
                    </li>
                    <li class="nav-item ">
                        <a class="nav-link" href="tentangkami.php"> Tentang Kami </a>
                    </li>
                    <li class="nav-item dropdown active">
                        <a class="nav-link dropdown-toggle" href="#" id="dropdownId" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Program Yang Ditawarkan</a>
                        <div class="dropdown-menu" aria-labelledby="dropdownId">
                            <a class="dropdown-item" href="asaslinux.php">Asas Linux</a>
                            <a class="dropdown-item active" href="programming.php">Programming dan Database</a>
                            <a class="dropdown-item" href="net.php">Networking</a>
                        </div>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="pendaftaran.php"> Pendaftaran Baru </a>
                    </li>
                </ul>
                <form class="form-inline my-2 my-lg-0">
                    <a class="btn btn-outline-success my-2 my-sm-0" type="button" href="login.php"> LOGIN </a>
                </form>
            </div>
        </nav>
        <br>
        <div class="container">
            <h5 style="text-align: center;color: aqua;">PENGENALAN KEPADA ASAS PROGRAMMING DAN DATABASE </h5>
            <br>
            <p style="color: cornsilk;">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi non neque ex. Ut maximus orci mi, id tempor mi vulputate nec. Donec orci orci, pretium a arcu ac, tempor ultrices elit. In hac habitasse platea dictumst. Vestibulum facilisis mauris ullamcorper, tristique mi at, hendrerit urna. Duis egestas rhoncus purus ac condimentum. Nullam semper augue velit, at rhoncus est convallis ac.</p>
            <p style="color: cornsilk;">Curabitur at arcu sem. Vestibulum pretium ante eget cursus condimentum. Aenean finibus at ipsum id facilisis. Phasellus tempus eget leo vitae molestie. In ornare ultricies faucibus. Nunc pharetra vestibulum diam ullamcorper tincidunt. Nam rutrum, tellus non commodo tincidunt, arcu erat convallis elit, et porta neque quam sed elit. Donec elementum arcu at tortor dictum, a condimentum odio imperdiet. Duis rutrum varius tortor, porta iaculis nisi maximus luctus. Vestibulum eros nisl, mollis vitae lectus ut, rhoncus hendrerit libero. Etiam ullamcorper orci quis tellus mollis rhoncus. Curabitur id rhoncus justo, at porttitor lorem.</p>
            <p style="color: cornsilk;">Cras egestas consequat nulla sed finibus. Nam eu velit quam. Curabitur nec ipsum nisi. In ultrices at dui cursus sollicitudin. Nulla quis accumsan augue. Nunc id tempus urna. Duis at nibh dui. Phasellus ullamcorper, felis rutrum pharetra faucibus, justo turpis iaculis ipsum, id ultricies mauris mi vitae nulla. Sed euismod in nulla sed ultricies. Aliquam non fermentum augue, ut pretium mi.</p>
            <p style="color: cornsilk;">Cras sed vestibulum ipsum, nec auctor ipsum. Sed sapien nulla, condimentum id iaculis non, elementum vitae eros. Donec suscipit neque ex, vel venenatis diam varius ut. Curabitur vel turpis est. Vestibulum et libero mauris. Sed imperdiet mauris pharetra enim convallis, nec aliquet enim consequat. Mauris accumsan auctor eros ut vulputate. Curabitur orci velit, ultrices sed consectetur et, commodo vitae orci.</p>
            <p style="color: cornsilk;">Fusce viverra odio in purus scelerisque, ullamcorper hendrerit purus vehicula. Aenean eu massa porta, suscipit metus vitae, semper ante. Donec feugiat hendrerit velit. Suspendisse dignissim maximus tellus quis pellentesque. Aenean convallis luctus nisi id pulvinar. Mauris tempus iaculis urna, nec tincidunt enim eleifend non. Suspendisse interdum bibendum consequat. Duis augue justo, scelerisque vel ultricies quis, elementum imperdiet lorem. Donec porttitor orci eget quam interdum dignissim. Etiam nec felis scelerisque, scelerisque libero ac, vehicula diam. Proin vitae placerat quam. Phasellus vel risus vitae massa efficitur ultrices. Nam non lobortis tortor.</p>
        </div>
        
      
    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
  </body>
</html>