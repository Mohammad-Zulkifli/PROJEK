<!-- status login -->
<?php
            session_start();
                if($_SESSION['username']==""){
                    header("location:login.php?pemberitahuan=gagal");
                }
                ?>
<!doctype html>
<html lang="en">
  <head>
	<title> KEPUTUSAN PERMOHONAN</title>
	<!-- Required meta tags -->
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

	<!-- Bootstrap CSS -->
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
  </head>
  <body background="img/edit.jpg" style="background-repeat: no-repeat; background-attachment: fixed; background-size: 100%;">
  <br>
  <br>
  <div class="container" style="background:#fff;">
					<br>
                    <table class="table">
                        <tr style="background:#1976D2; text-align: center;">
                            <th class="text-white" colspan="4">MAKLUMAT PEMOHON</th>
                        </tr>
						<br>
                        <?php
						include 'connection.php';
                        $id = $_REQUEST['id'];
                        $sql = "select * from permohonan where id='$id'";
                        $res = mysqli_query($conn, $sql);
                        $row = mysqli_fetch_assoc($res);
						$nama = $row['nama'];
                        $umur = $row['umur'];
                        $telefon = $row['telefon'];
                        $model_laptop = $row['model_laptop'];
                        $pro = $row['pro'];
                        $ram = $row['ram'];
                        $kursus = $row['kursus'];
                        $hari = $row['hari'];
						$masa = $row['masa'];
						$status = $row['status'];
						if($row['status'] == '0'){ // status pending
							$status = "Sedang Diproses";
							$bg = "#1976D2";
							$color = "#fff";
						}
						if($row['status'] == '1'){// status Terima
							$status = "Terima";
							$bg = "#4CAF50";
							$color = "#fff";
						}
						if($row['status'] == '2'){// status Penolakkan
							$status = "Gagal";
							$bg = "#D32F2F";
							$color = "#fff";
						}
						if($row['status'] == '3'){// status Penolakkan
							$status = "Dikeluarkan";
							$bg = "#000000";
							$color = "#fff";
						}

                       
                        ?>
                        <tr >
                            <td ><b>Nama Pemohon</b></td>
                            <td >: <?php echo "$nama"; ?></td>
                            <td ><b>Umur</b></td>
                            <td >: <?php echo "$umur"; ?></td>
                        </tr>
                        <tr >
                            <td><b>Nombor Telefon</b></td>
                            <td>: <?php echo "$telefon"; ?></td>
                            <td><b>Model Laptop</b></td>
                            <td>: <?php echo "$model_laptop"; ?></td>
                        </tr>
                        <tr >
                            <td><b>Proccessor</b></td>
                            <td>: <?php echo "$pro"; ?></td>
                            <td><b>RAM</b></td>
                            <td>: <?php echo "$ram"; ?></td>
                        </tr>
                        <tr>
                            <td><b>Kursus Dimohon</b></td>
                            <td>: <?php echo "$kursus"; ?></td>
                            <td><b>Hari</b></td>
                            <td>: <?php echo "$hari"; ?></td>
                        </tr>
						<tr >
                            <td><b>Masa</b></td>
                            <td>: <?php echo "$masa"; ?></td>
                            <td><b>Status Permohonan</b></td>
                            <td>: <span class="badge" style="background:<?php echo "$bg";?>;color:<?php echo "$color";?>;"><?php echo "$status";?></span></td>
							<td style="text-align:center;">
                                    <?php if($row['status'] == 0) { // hanya pending sahaja?>
									<?php }
									?>
                        </tr>
					</table>
					<?php
	include 'connection.php';
	$id = $_GET['id'];
	$query = mysqli_query($conn,"select * from permohonan where id='$id'");
	while($data = mysqli_fetch_array($query)){
		?>

				<div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                            <thead>
                                <tr>
                                        <th style="text-align: center;">SYARAT - SYARAT PERMOHONAN</th>
					            </tr>
								<tr>
									<td>
										1.	BERUMUR 15 - 40 TAHUN.
									</td>
								</tr>
								<tr>
									<td>
										2.	WARGANEGARA MALAYSIA.
									</td>
								</tr>
								<tr>
									<td>
										3.	BERMINAT UNTUK MENYERTAI.
									</td>
								</tr>
								<tr>
									<td>
										4.	BERDISIPLIN DAN BERKOMUNIKASI DENGAN BAIK ANTARA PELAJAR DAN GURU
									</td>
								</tr>
								<tr>
									<td>
										5.	PELAJAR YANG MELANGGAR MANA - MANA PERATURAN AKAN DI <B>DIKELUARKAN</B> SERTA - MERTA
									</td>
								</tr>
								
                            </thead>
					</div>
				</div>

			<form method="post" action="update_Permohonan.php">
				<table class="container">
					<tr>			
						<td style="text-align:center;">
							<input type="hidden" name="id" value="<?php echo $data['id']; ?>">
                            <select style="width:50%;" name="status"  value="<?php echo $data['status']; ?>">
								<option value="#">Sila Pilih</option>
								<option value="0">Sedang Diproses..</option>
                    	        <option value="1">Diterima..</option>
                                <option value="2">Ditolak..</option>
								<option value="3">Dikeluarkan..</option>
                            </select>
						</td>
					</tr>
					<tr>
						<td style="text-align:center;">
						<br>
						<div class="form-group">
							<button type="submit" style="width:30%" name="submit" value="simpan" class="btn btn-primary"><i class="fas fa-sign-in-alt"></i> Kemaskini</button>
						</div>
						<div class="form-group">
							<input class="btn btn-primary" type="button" style="width:30%" value="Batal" onclick="history.back(-1)"/><i class="fas fa-sign-in-alt"></i>
						</div>
						</td>
					</tr>		
				</table>
			</form>
					<?php 
				}
				?>
					
								
	<!-- jQuery first, then Popper.js, then Bootstrap JS -->
	<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
	<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
	<script src="https://cdn.jsdelivr.net/npm/sweetalert2@10"></script>
	
  </body>
</html>