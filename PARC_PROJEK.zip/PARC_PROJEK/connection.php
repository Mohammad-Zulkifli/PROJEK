<?php 
$conn = mysqli_connect("localhost","root","","parc");
 
// Check connection
if (mysqli_connect_errno()){
	echo "Sambungan database gagal : " . mysqli_connect_error();
}
 
?>