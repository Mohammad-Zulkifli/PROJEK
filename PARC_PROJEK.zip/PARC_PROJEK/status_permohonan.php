<?php
            session_start();
                if($_SESSION['username']==""){
                    header("location:login.php?pemberitahuan=gagal");
                }
                ?>
<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title> STATUS PERMOHONAN</title>

    <!-- Custom fonts for this template-->
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link
        href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i"
        rel="stylesheet">

    <!-- Custom styles for this template-->
    <link href="css/sb-admin-2.min.css" rel="stylesheet">

    <!-- Custom styles for this page -->
     <link href="vendor/datatables/dataTables.bootstrap4.min.css" rel="stylesheet">

</head>

<body id="page-top">

    <!-- Page Wrapper -->
    <div id="wrapper">

                    <!-- Sidebar -->
                    <ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">

                        <!-- Sidebar - Brand
                        <a class="sidebar-brand d-flex align-items-center justify-content-center" href="halaman_utama.php">
                            <div class="sidebar-brand-icon rotate-n-15">
                                <i class="fas fa-laugh-wink"></i>
                            </div>
                            <div class="sidebar-brand-text mx-3">Admin PARC </div>
                        </a>
                    -->

                    <a class="sidebar-brand d-flex align-items-center justify-content-center" href="#">
                        
                        <img class="img-profile rounded-circle" style="width: 30px; height: 30px;" src="img/undraw_profile.svg">
                    
                    <div class="sidebar-brand-text mx-3"> PELAJAR PARC </div>
                    </a>

                        <!-- Divider -->
                        <hr class="sidebar-divider my-0">

                        <!-- Nav Item - Dashboard -->
                        <li class="nav-item">
                            <a class="nav-link" href="halaman_pelajar.php">
                                <i class="fas fa-fw fa-tachometer-alt"></i>
                                <span>Dashboard</span></a>
                        </li>

                        <!-- Divider -->
                        <hr class="sidebar-divider my-0">

                        <li class="nav-item active">
                            <a class="nav-link" href="status_permohonan.php">
                                <i class="fa fa-user-edit" aria-hidden="true"></i>
                                <span>Status Permohonan</span></a>
                        </li>
                        
                        <hr class="sidebar-divider my-0">

                        <li class="nav-item">
                            <a class="nav-link" href="maklumat_pemohon.php">
                                <i class="fa fa-user-shield" aria-hidden="true"></i>
                                <span>Maklumat Pemohon</span></a>
                        </li>

                        <hr class="sidebar-divider my-0">

                        <li class="nav-item">
                            <a class="nav-link" href="logout.php">
                                <i class="fas fa-power-off" aria-hidden="true"></i>
                                <span>Logout</span></a>
                        </li>

                        <!-- Divider -->
                        <hr class="sidebar-divider d-none d-md-block">

                        <!-- Sidebar Toggler (Sidebar) -->
                        <div class="text-center d-none d-md-inline">
                            <button class="rounded-circle border-0" id="sidebarToggle"></button>
                        </div>


                        <!-- Sidebar Message 
                        <div class="sidebar-card">
                            <img class="sidebar-card-illustration mb-2" src="img/undraw_rocket.svg" alt="">
                            <p class="text-center mb-2"><strong>SB Admin Pro</strong> is packed with premium features, components, and more!</p>
                            <a class="btn btn-success btn-sm" href="https://startbootstrap.com/theme/sb-admin-pro">Upgrade to Pro!</a>
                        </div>
                    -->

                    </ul>
                    <!-- End of Sidebar -->

                    <!-- Content Wrapper -->
                    <div id="content-wrapper" class="d-flex flex-column">

                        <!-- Main Content -->
                        <div id="content">

                            

                            <!-- Topbar -->
                            <nav class="navbar navbar-expand topbar mb-4 static-top shadow" style="background-color: rgb(148, 51, 228);">


                                <!--imej PARC dalam top bar-->
                                <div class="container">
                                    <img style="width: 100px; height: 50px;" src="img/linux.jpeg" >
                                
                                    <img style="width: 100px; height: 50px;" src="img/parc3.jpeg">

                                    <img style="width: 100px; height: 50px;" src="img/parc1.jpg">
                                </div>

                            </nav>

                            

                    <!-- Begin Page Content -->
                    <div class="container-fluid">

                        <!-- Page Heading 
                        <h1 class="h3 mb-2 text-gray-800">Tables</h1>
                        <p class="mb-4">DataTables is a third party plugin that is used to generate the demo table below.
                            For more information about DataTables, please visit the <a target="_blank"
                                href="https://datatables.net">official DataTables documentation</a>.</p>
                        -->

                        <!-- DataTales Example -->
                        <div class="card shadow mb-4">
                            <div class="card-header py-3">
                                <h6 class="m-0 font-weight-bold text-primary">Status Permohonan</h6>
                            </div>
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                                        <thead>
                                            <tr>
                                                <th style="text-align:center; width:10px;">Bil</th>
                                                <th style="text-align:center;">Daftar</th>
                                                <th style="text-align:center;">Nama</th>
                                                <th style="text-align:center;">Kursus</th>
                                                <th style="text-align:center;">Tarikh Permohonan</th>
                                                <th style="text-align:center;">Status</th>
                                            </tr>
                                        </thead>
                                        <?php 
                                            include 'connection.php';
                                            $bil = 1;

                                            $id = $_SESSION['id'];
                                            $id = mysqli_real_escape_string($conn, $id);
                                            $query = "SELECT * FROM permohonan WHERE id='$id'";
                                            $result = mysqli_query($conn, $query);
                                            while($row = mysqli_fetch_array($result)) {
                                                if($row['status'] == '0'){ // status pending
                                                    $status = "Permohonan Sedang Diproses..";
                                                    $bg = "#1976D2";
                                                    $color = "#fff";
                                                }
                                                if($row['status'] == '1'){// status Terima
                                                    $status = "Permohonan Anda Diterima";
                                                    $bg = "#4CAF50";
                                                    $color = "#fff";
                                                }
                                                if($row['status'] == '2'){// status Penolakkan
                                                    $status = "Maaf Permohonan Anda Ditolak";
                                                    $bg = "#D32F2F";
                                                    $color = "#fff";
                                                }
                                                if($row['status'] == '3'){// status Penolakkan
                                                    $status = "Maaf Anda Telah Dikeluarkan";
                                                    $bg = "#000000";
                                                    $color = "#fff";
                                                }

                                            
                                        
                                        ?>
                                                
                                            
                                            <tr>
                                                <td style="text-align:center;"><?php echo $bil++; ?></td>
                                                <td style="text-align:center;"><?php echo $row['id']; ?></td>
                                                <td style="text-align:center;"><?php echo $row['nama']; ?></td>
                                                <td style="text-align:center;"><?php echo $row['kursus']; ?></td> 
                                                <td style="text-align:center;"><?php echo date('d-m-y h:i:sa', strtotime($row['tarikh_permohonan'])); ?></td>      
                                                <td style="text-align:center;"><span class="badge" style="text-align: center; background:<?php echo "$bg";?>;color:<?php echo "$color";?>;"><?php echo "$status";?></span></td>
                                            </tr>
                                        
                                    </table>
                                </div>
                            </div>
                        </div>
                                <div class="card" style="background:<?php echo "$bg"; ?>;color:<?php echo "$color"; ?>; padding:15px; width:380px; display:block; margin-right:auto; margin-left:auto;">
                                    <h4><?php echo "$status"; ?><h4>
                                </div> 
                                <br>  
                                <?php
                                            if ($row['status'] == '2') { // status Penolakkan
                                            ?>
                                
                            <form method="post" action="update_rayuan_db.php">
                                <div class="card border-primary" style=" padding:15px; width: auto; display:block; margin-right:auto; margin-left:auto;">
                                    <div class="card-body" style="text-align: center;">
                                    <h4 class="card-title">PERMOHONAN SEMAKKAN SEMULA</h4>
                                    <table class="table table-bordered" style="margin-top:20px;">
                                                <tr style="background:#1976D2;">
                                                    <th colspan="8" class="text-white"><b>Alasan Untuk Penyertaan</b></th>
                                                </tr>
                                                <tr>
                                                    <td>
                                                    <div style="text-align: left;">
                                                        <textarea type="text" name="rayuan" id="" cols="130" rows="10"></textarea>
                                                    </div>
                                                    </td>
                                                <tr>
                                                    <th>
                                                        1.  PEMOHON YANG MEMBUAT RAYUAN KALI PERTAMA DAN <b>BERSTATUS DITOLAK</b> AKAN DI LABEL <b>DIKELUARKAN</b>.
                                                    </th>
                                                </tr>
                                                </tr>
                                        </div>
                                </div>
                                                <?php
                                                    include 'connection.php';
                                                    
                                                    $query = mysqli_query($conn,"select * from permohonan where id='$id'");
                                                    while($data = mysqli_fetch_array($query)){
                                                        ?>
                                            
                                    
                                    <form method="post" action="update_Permohonan.php">
                                        <table class="container">
                                            <tr>			
                                                <td style="text-align:center;">
                                                    <input type="hidden" name="id" value="<?php echo $data['id']; ?>">
                                                    <select style="width:50%;" name="status"  value="<?php echo $data['status']; ?>">
                                                        <option value="#">Sila Pilih</option>
                                                        <option value="0">Hantar Permohonan Rayuan..</option>
                                                    </select>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td style="text-align:center;">
                                                <br>
                                                <div class="form-group">
                                                    <button type="submit" style="width:30%" name="submit" value="simpan" class="btn btn-primary"><i class="fas fa-paper-plane"></i>  Hantar</button>
                                                </div>
                                                </td>
                                            </tr>		
                                        </table>
                                    </form>
                                    <?php } ?>
                                    <?php } ?>
                                    <?php } ?>

                    </div>
                </div>
                <!-- End of Main Content -->
            <br>
        <!-- Footer -->
        <footer class="sticky-footer bg-white">
            <div class="container my-auto">
                <div class="copyright text-center my-auto">
                    <span>Copyright &copy; ZULKIFLI 2021</span>
                </div>
            </div>
        </footer>
        </div>
    
    <!-- End of Footer -->
                

    <!-- Bootstrap core JavaScript-->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Core plugin JavaScript-->
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

    <!-- Custom scripts for all pages-->
    <script src="js/sb-admin-2.min.js"></script>

    <!-- Page level plugins -->
    <script src="vendor/chart.js/Chart.min.js"></script>

    <!-- Page level custom scripts -->
    <script src="js/demo/chart-area-demo.js"></script>
    <script src="js/demo/chart-pie-demo.js"></script>

     <!-- Page level plugins -->
     <script src="vendor/datatables/jquery.dataTables.min.js"></script>
     <script src="vendor/datatables/dataTables.bootstrap4.min.js"></script>

    <!-- Page level custom scripts -->
    <script src="js/demo/datatables-demo.js"></script>


</body>
</html>