<?php 

session_start();

?>
<!doctype html>
<html lang="en">
  <head>
    <title> Halaman Login</title>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <!-- Custom fonts for this template-->
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
  </head>
  <body background="img/login.jpg" style="background-repeat: no-repeat; background-attachment: fixed; background-size: 100%;">
        <nav class="navbar navbar-expand-sm navbar-light bg-light">
            <button class="navbar-toggler d-lg-none" type="button" data-toggle="collapse" data-target="#collapsibleNavId" aria-controls="collapsibleNavId"
                aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="collapsibleNavId">
                <ul class="navbar-nav mr-auto mt-2 mt-lg-0">
                    <li class="nav-item">
                        <a class="nav-link" href="index.php">Home</a>
                    </li>
                    <li class="nav-item ">
                        <a class="nav-link" href="tentangkami.php"> Tentang Kami </a>
                    </li>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="dropdownId" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Program Yang Ditawarkan</a>
                        <div class="dropdown-menu" aria-labelledby="dropdownId">
                            <a class="dropdown-item" href="asaslinux.php">Asas Linux</a>
                            <a class="dropdown-item" href="programming.php">Programming dan Database</a>
                            <a class="dropdown-item" href="net.php">Networking</a>
                        </div>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="pendaftaran.php"> Pendaftaran Baru </a>
                    </li>
                </ul>
                <form class="form-inline0 my-2 my-lg-0">
                    <a class="btn btn-outline-success my-2 my-sm-0" type="button" href="login.php"> LOGIN </a>
                </form>
            </div>
        </nav>
        <br>
        <br>
        <br>
        <br>
        <br>
        <br>
            <div class="container">
                <div class="container">
                    <div class="row justify-content-center mt-5">
                      <div class="col-md-4">
                        <div class="card">
                          <div class="card-header bg-transparent mb-0"><h5 class="text-center">Halaman  <span class="font-weight-bold text-primary">Login <i class="fas fa-key"></i></span></h5></div>
                          <div class="card-body">
                            <form action="login_db.php" method="post">
                              <div class="form-group">
                                <input type="text" name="username" class="form-control" placeholder="Username" required>
                              </div>
                              <div class="form-group">
                                <input type="password" name="password" id="password" class="form-control" placeholder="Password" required>
                              </div>
                              <div class="form-group">
                              <!-- notification  -->
                              <?php 
	                                if(isset($_GET['pemberitahuan'])){
		                                if($_GET['pemberitahuan'] == "gagal"){
			                                echo "Login gagal! username dan password salah!";
		                              }else if($_GET['pemberitahuan'] == "logout"){
			                                echo "Anda telah berhasil logout";
		                              }else if($_GET['pemberitahuan'] == "belum_login"){
			                                echo "Anda harus login untuk mengakses halaman admin";
		                              }
	                                }
                                  ?>
                                  </div>
                              <div class="form-group">
                              <input type="checkbox" id="checkbox" class="form-checkbox"> Tunjukan Kata Laluan
                              </div>
                              <div>
                                <p>  Perlukan Bantuan? <a href="bantuan.php">Bantuan</a></p>
                              </div>
                              <div class="form-group">
                                <button type="submit" style="width:100%" name="submit" value="LOGIN" class="btn btn-primary"><i class="fas fa-sign-in-alt"></i> LOGIN</button>
                              </div>
                                </form>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
      
    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
    <script>
  $(document).ready(function(){
    $('#checkbox').click(function() {
        if($(this).is(':checked')){
            $('#password').attr('type','text');
        }else{
            $('#password').attr('type','password');
        }
    });
});
</script>
  </body>
</html>