<!doctype html>
<html lang="en">
  <head>
    <title> Pendaftaran Pelajar</title>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <!-- Custom fonts for this template-->
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
  </head>
  <body background="img/ai.jpg" style="background-repeat: no-repeat; background-attachment: fixed; background-size: 100%;">
        <nav class="navbar navbar-expand-sm navbar-dark bg-transparent fixed-top">
            <button class="navbar-toggler d-lg-none" type="button" data-toggle="collapse" data-target="#collapsibleNavId" aria-controls="collapsibleNavId"
                aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="collapsibleNavId">
                <ul class="navbar-nav mr-auto mt-2 mt-lg-0">
                    <li class="nav-item">
                        <a class="nav-link" href="index.php">Home</a>
                    </li>
                    <li class="nav-item ">
                        <a class="nav-link" href="tentangkami.php"> Tentang Kami </a>
                    </li>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="dropdownId" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Program Yang Ditawarkan</a>
                        <div class="dropdown-menu" aria-labelledby="dropdownId">
                            <a class="dropdown-item" href="asaslinux.php">Asas Linux</a>
                            <a class="dropdown-item" href="programming.php">Programming dan Database</a>
                            <a class="dropdown-item" href="net.php">Networking</a>
                        </div>
                    </li>
                    <li class="nav-item active">
                        <a class="nav-link" href="pendaftaran.php"> Pendaftaran Baru </a>
                    </li>
                </ul>
                <form class="form-inline my-2 my-lg-0">
                    <a class="btn btn-outline-success my-2 my-sm-0" type="button" href="login.php"> LOGIN </a>
                </form>
            </div>
        </nav>
        <br>
        <br>
        
        <?php
          
          include 'connection.php';

          // take a big value
          $query = mysqli_query($conn, "SELECT max(id) as TheBigValue FROM permohonan");
          $data = mysqli_fetch_array($query);
          $code = $data['TheBigValue'];

          // mengambil angka dari kode barang terbesar, menggunakan fungsi substr
          // dan diubah ke integer dengan (int)
          $bill = (int) substr($code, 4, 4);

          // bilangan yang diambil ini ditambah 1 untuk menentukan nombor urut berikutnya
          $bill++;

          // membentuk kode baru
          // perintah sprintf("%03s", $bill); berguna untuk membuat string menjadi 3 karakter
          // contoh arahan sprintf("%03s", 15); maka akan menghasilkan '015'
          // angka dan huruf akan digabungkan
          $huruf = "PARC";
          $code = $huruf . sprintf("%04s", $bill);
          ?>


            <div class="container">
                <div class="row justify-content-center mt-5">
                  <div class="col-md-4">
                    <div class="card">
                      <div class="card-header bg-transparent mb-0"><h5 class="text-center">SILA ISIKAN <span class="font-weight-bold text-primary">MAKLUMAT ANDA</span></h5></div>
                      <div class="card-body">
                        <form method="post" action="permohonan_db.php">
                          <div class="form-group">
                            <input type="text" name="id" class="form-control" required="required" value="<?php echo $code ?>" hidden readonly>
                          </div>
                          <div class="form-group">
                            <input type="text" name="nama" required="required" class="form-control" placeholder="NAMA PENUH">
                          </div>
                          <div class="form-group">
                            <input type="text" name="umur" required="required" class="form-control" placeholder="UMUR">
                          </div>
                          <div class="form-group">
                            <input type="text" name="telefon" required="required" class="form-control" placeholder="NOMBOR TELEFON">
                          </div>
                          <div class="form-group">
                            <input type="text" name="model_laptop" required="required" class="form-control" placeholder="MODEL LAPTOP">
                          </div>
                          <div class="form-group">
                            <input type="text" name="pro" required="required" class="form-control" placeholder="PROCCESSOR">
                          </div>
                          <div class="form-group">
                            <input type="text" name="ram" required="required" class="form-control" placeholder="RAM">
                          </div>
                          <div class="form-group"> 
                                <select class="form-control" name="kursus" required="required">
                                    <option value="">KURSUS</option>
                                    <option value="ASAS LINUX">ASAS LINUX</option>
                                    <option value="PROGRAMMING AND DATABASE">PROGRAMMING AND DATABASE</option>
                                    <option value="NETWORKING">NETWORKING</option>
                                </select>
                                </div>
                                <div class="form-group"> 
                                    <select class="form-control" name="hari" required="required">
                                        <option value="">HARI</option>
                                        <option value="KHAMIS">KHAMIS</option>
                                        <option value="JUMAAT">JUMAAT</option>
                                        <option value="SABTU">SABTU</option>
                                        <option value="AHAD">AHAD</option>
                                    </select>
                                    </div>
                                    <div class="form-group"> 
                                        <select class="form-control" name="masa" required="required">
                                            <option value="">MASA</option>
                                            <option value="11.00AM-1.00PM">11.00AM - 1.00PM</option>
                                            <option value="10.00AM-11.00AM">10.00AM - 11.00AM</option>
                                            <option value="3.00PM-4.00PM">3.00PM - 4.00PM</option>
                                            <option value="8.00PM-9.00PM">8.00PM - 9.00PM</option>
                                            <option value="8.00PM-10.00PM">8.00PM - 10.00PM</option>
                                            <option value="9.00AM-11.00PM">9.00AM - 11.00PM</option>
                                        </select>
                                    </div>
                                    <div class="form-group">
                                        <input type="text" name="username" required="required" class="form-control" placeholder="USERNAME">
                                      </div>
                                    <div class="form-group">
                                        <input type="password" name="password" required="required" pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}" title="Must contain at least one number and one uppercase and lowercase letter, and at least 8 or more characters" class="form-control" placeholder="PASSWORD">
                                      </div>
                                    <div class="form-group">
                                        <input type="email" name="email" required="required" class="form-control" placeholder="E-MEL">
                                    </div>
                                    <div class="form-group">
                                        <input type="text" name="status" required="required" class="form-control" value="PENDING...." hidden>
                                    </div>
                                    <div class="form-group">
                                        <input type="text" name="level" required="required" class="form-control" value="pelajar" hidden>
                                    </div>
                                    <hr>
                          <div class="form-group">
                          <button type="submit" name="submit" class="btn btn-primary btn-block"><i class="fas fa-edit"></i> Daftar </button>
                          <button type="reset" class="btn btn-danger btn-block"><i class="fas fa-redo"></i> Reset </button>
                          </div>
                        </form>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <br>
          <br>
          
    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
  

    <!-- Core plugin JavaScript-->
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

    <!-- Custom scripts for all pages-->
    <script src="js/sb-admin-2.min.js"></script>

    <!-- Page level plugins -->
    <script src="vendor/chart.js/Chart.min.js"></script>

    <!-- Page level custom scripts -->
    <script src="js/demo/chart-area-demo.js"></script>
    <script src="js/demo/chart-pie-demo.js"></script>

     <!-- Page level plugins -->
     <script src="vendor/datatables/jquery.dataTables.min.js"></script>
     <script src="vendor/datatables/dataTables.bootstrap4.min.js"></script>

    <!-- Page level custom scripts -->
    <script src="js/demo/datatables-demo.js"></script>

    <script src="js/random.js"></script> 
  </body>
</html>