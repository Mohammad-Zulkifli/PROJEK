<!-- status login -->
<?php
            session_start();
                if($_SESSION['username']==""){
                    header("location:login.php?pemberitahuan=gagal");
                }
                ?>
<!doctype html>
<html lang="en">
  <head>
	<title> KEMASKINI MAKLUMAT</title>
	<!-- Required meta tags -->
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

	<!-- Bootstrap CSS -->
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
  </head>
  <body background="img/edit.jpg" style="background-repeat: no-repeat; background-attachment: fixed; background-size: 100%;">
  <br>
  <br> 
                       
                
					<br> 
                    <?php
                            include 'connection.php';
                            $id = $_REQUEST['id'];
                            $sql = "select * from permohonan where id='$id'";
                            $res = mysqli_query($conn, $sql);
                            $row = mysqli_fetch_assoc($res);
                            $nama = $row['nama'];
                            $umur = $row['umur'];
                            $telefon = $row['telefon'];
                            $model_laptop = $row['model_laptop'];
                            $pro = $row['pro'];
                            $ram = $row['ram'];
                            $kursus = $row['kursus'];
                            $hari = $row['hari'];
                            $masa = $row['masa'];
                            $status = $row['status'];
                        ?>	
            <form method="post" action="kemaskini_db.php">
                <div class="container" style="background:#fff;">
                    <table class="table">
                        <tr style="background:#1976D2; text-align: center;">
                            <th class="text-white" colspan="4" >KEMASKINI MAKLUMAT PEMOHON </th>
                        </tr>
						<br>
                       
                        <tr >
                            <td><b>Nombor Daftar</b></td>
                            <td>: <input style="width:97%" type="text" name="id" value="<?php echo "$id" ?>" readonly/></td>
                            <td ><b>Umur</b></td>
                            <td >: <input style="width:97%" type="text" name="umur" value="<?php echo "$umur" ?>"/></td>
                        </tr>
                        <tr >
                            <td ><b>Nama Pemohon</b></td>
                            <td >: <input style="width:97%" type="text" name="nama" value="<?php echo "$nama" ?>"/></td>
                            <td><b>Nombor Telefon</b></td>
                            <td>: <input style="width:97%" type="text" name="telefon" value="<?php echo "$telefon" ?>"/></td>
                        </tr>
                        <tr >
                            <td><b>Model Laptop</b></td>
                            <td>: <input style="width:97%" type="text" name="model_laptop" value="<?php echo "$model_laptop" ?>"/></td>
                            <td><b>Proccessor</b></td>
                            <td>: <input style="width:97%" type="text" name="pro" value="<?php echo "$pro" ?>"/></td>
                        </tr>
                        <tr>
                            <td><b>RAM</b></td>
                            <td>: <input style="width:97%" type="text" name="ram" value="<?php echo "$ram" ?>"/></td>
                            <td><b>Kursus Dimohon</b></td>
                            <td>: <input style="width:97%" type="text" name="kursus" value="<?php echo "$kursus" ?>" readonly/></td>
                        </tr>
						<tr >
                            <td><b>Hari</b></td>
                            <td>: <input style="width:97%" type="text" name="hari" value="<?php echo "$hari" ?>" readonly/></td>
                            <td><b>Masa</b></td>
                            <td>: <input style="width:97%" type="text" name="masa" value="<?php echo "$masa" ?>" readonly/></td>
                        </tr>
					</table>
				<table class="container">
					<tr>
						<td style="text-align:center;">
						<br>
						<div class="form-group">
							<button type="submit" style="width:30%" name="submit" value="simpan" class="btn btn-primary"><i class="fas fa-sign-in-alt"></i> Kemaskini</button>
						</div>
						<div class="form-group">
							<input class="btn btn-primary" type="button" style="width:30%" value="Batal" onclick="history.back(-1)"/><i class="fas fa-sign-in-alt"></i>
						</div>
						</td>
					</tr>		
                    </form>	
				</table>
		
					
					
								
	<!-- jQuery first, then Popper.js, then Bootstrap JS -->
	<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
	<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
	<script src="https://cdn.jsdelivr.net/npm/sweetalert2@10"></script>
    <script>
  $(document).ready(function(){
    $('#checkbox').click(function() {
        if($(this).is(':checked')){
            $('#password').attr('type','text');
        }else{
            $('#password').attr('type','password');
        }
    });
});
</script>
	
  </body>
</html>