<?php
include 'connection.php';

if (isset($_POST['submit'])) {

	$id = $_POST['id'];
$nama = $_POST['nama'];
$umur = $_POST['umur'];
$telefon = $_POST['telefon'];
$model_laptop = $_POST['model_laptop'];
$pro = $_POST['pro'];
$ram = $_POST['ram'];
$kursus = $_POST['kursus'];
$hari = $_POST['hari'];
$masa = $_POST['masa'];
$username = $_POST['username'];
$password = md5($_POST['password']);
$emel = $_POST['email'];
$status = $_POST['status'];
$level = $_POST['level'];

$query = "INSERT INTO permohonan(id,nama,umur,telefon,model_laptop,pro,ram,kursus,hari,masa,status) VALUES ('$id','$nama','$umur','$telefon','$model_laptop','$pro','$ram','$kursus','$hari','$masa','$status');";

$query .= "INSERT INTO user(id,username,password,emel,level) VALUES ('$id','$username','$password','$emel','$level')";

$result = mysqli_multi_query($conn, $query);



	if($result){
	echo "<script type='text/javascript'>
	      setTimeout(function () { 
	        Swal.fire({
	        		icon: 'success',
	        		type: 'success',
	                title: 'Tahniah!!',
	                text: 'Pendaftaran Berjaya.',
	                timer: 3200,
	                showConfirmButton: true
	            });   
	      },10);  
	      window.setTimeout(function(){ 
	        window.location.replace('pendaftaran.php');
	      } ,3000); 
	      </script>";
}else{
	echo "pendaftaran Gagal!";

}
}
?>
<script src="js/jquery-3.4.1.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@10"></script>
