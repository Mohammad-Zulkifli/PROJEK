-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 28, 2021 at 03:25 AM
-- Server version: 10.4.17-MariaDB
-- PHP Version: 8.0.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `parc`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `emel` varchar(255) NOT NULL,
  `level` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `username`, `password`, `name`, `emel`, `level`) VALUES
(1, 'admin', '21232f297a57a5a743894a0e4a801fc3', 'admin', 'admin@parc.com', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `permohonan`
--

CREATE TABLE `permohonan` (
  `id` varchar(10) NOT NULL,
  `nama` varchar(255) NOT NULL,
  `umur` int(3) NOT NULL,
  `telefon` varchar(12) NOT NULL,
  `model_laptop` varchar(255) NOT NULL,
  `pro` varchar(255) NOT NULL,
  `ram` varchar(255) NOT NULL,
  `kursus` varchar(255) NOT NULL,
  `hari` varchar(255) NOT NULL,
  `masa` varchar(255) NOT NULL,
  `status` int(11) NOT NULL DEFAULT 0,
  `rayuan` varchar(255) NOT NULL,
  `tarikh_permohonan` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `permohonan`
--

INSERT INTO `permohonan` (`id`, `nama`, `umur`, `telefon`, `model_laptop`, `pro`, `ram`, `kursus`, `hari`, `masa`, `status`, `rayuan`, `tarikh_permohonan`) VALUES
('PARC0001', 'MOHAMMAD ZULKIFLI BIN MOHD RAZALI', 21, '0133625448', 'ACER PREDATOR HELIOS 300', 'I7', '16GB', 'PROGRAMMING AND DATABASE', 'AHAD', '10.00AM-11.00AM', 1, '', '2021-02-21 14:14:23'),
('PARC0002', 'MUHAMAD SAFUAN BIN AHMAD', 21, '0133252116', 'ACER', 'RYZEN9', '32GB', 'ASAS LINUX', 'KHAMIS', '11.00AM-1.00PM', 0, '', '2021-02-21 17:24:57'),
('PARC0004', 'SITI ZAIYANI BINTI MOHD RAZALI', 25, '0166659999', 'ACER PREDATOR HELIOS 300', 'RYZEN9', '16GB', 'NETWORKING', 'AHAD', '11.00AM-1.00PM', 3, '', '2021-02-21 17:26:23'),
('PARC0005', 'MOHAMAD ZAKUAN BIN MOHD RAZALI', 13, '0166525498', 'ACER PREDATOR HELIOS 300', 'RYZEN9', '32GB', 'NETWORKING', 'SABTU', '11.00AM-1.00PM', 0, '', '2021-02-21 17:27:21');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` varchar(10) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `emel` varchar(255) NOT NULL,
  `level` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `username`, `password`, `emel`, `level`) VALUES
('PARC0001', 'zul', '2d5ac9f99648da57b097e8c5ff528b56', 'zul@gmail.com', 'pelajar'),
('PARC0002', 'safuan', 'f05be24e5ea8f1a1999c1b49890961ef', 'safuan@hotmail.com', 'pelajar'),
('PARC0004', 'yani', '34d2592d3619c2e3944d01b4c1676e95', 'yani@gmail.com', 'pelajar'),
('PARC0005', 'zakuan', 'c80821e51c28105104f374565b437661', 'zakuan@gmail.com', 'pelajar');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `permohonan`
--
ALTER TABLE `permohonan`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
