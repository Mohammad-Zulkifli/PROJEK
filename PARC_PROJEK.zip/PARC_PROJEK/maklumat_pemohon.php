<!-- status login -->
<?php
            session_start();
                if($_SESSION['username']==""){
                    header("location:login.php?pemberitahuan=gagal");
                }
                ?>
<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>MAKLUMAT PEMOHON</title>

    <!-- Custom fonts for this template-->
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link
        href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i"
        rel="stylesheet">

    <!-- Custom styles for this template-->
    <link href="css/sb-admin-2.min.css" rel="stylesheet">

    <!-- Custom styles for this page -->
    <link href="vendor/datatables/dataTables.bootstrap4.min.css" rel="stylesheet">

</head>

<body id="page-top">

     <!-- Page Wrapper -->
     <div id="wrapper">

        <!-- Sidebar -->
        <ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">

            <!-- Sidebar - Brand
            <a class="sidebar-brand d-flex align-items-center justify-content-center" href="halaman_utama.php">
                <div class="sidebar-brand-icon rotate-n-15">
                    <i class="fas fa-laugh-wink"></i>
                </div>
                <div class="sidebar-brand-text mx-3">Admin PARC </div>
            </a>
        -->

        <a class="sidebar-brand d-flex align-items-center justify-content-center" href="#">
            
            <img class="img-profile rounded-circle" style="width: 30px; height: 30px;" src="img/undraw_profile.svg">
        
            <div class="sidebar-brand-text mx-3"> PELAJAR PARC </div>
    </a>

            <!-- Divider -->
            <hr class="sidebar-divider my-0">

            <!-- Nav Item - Dashboard -->
            <li class="nav-item">
                <a class="nav-link" href="halaman_pelajar.php">
                    <i class="fas fa-fw fa-tachometer-alt"></i>
                    <span>Dashboard</span></a>
            </li>

            <!-- Divider -->
            <hr class="sidebar-divider my-0">

            <li class="nav-item">
                <a class="nav-link" href="status_permohonan.php">
                    <i class="fa fa-user-edit" aria-hidden="true"></i>
                    <span>Status Permohonan</span></a>
            </li>
            
            <hr class="sidebar-divider my-0">

            <li class="nav-item active">
                <a class="nav-link" href="maklumat_pemohon.php">
                    <i class="fa fa-user-shield" aria-hidden="true"></i>
                    <span>Maklumat Pemohon</span></a>
            </li>

            <hr class="sidebar-divider my-0">

            <li class="nav-item">
                <a class="nav-link" href="logout.php">
                    <i class="fas fa-power-off" aria-hidden="true"></i>
                    <span>Logout</span></a>
            </li>

            <!-- Divider -->
            <hr class="sidebar-divider d-none d-md-block">

            <!-- Sidebar Toggler (Sidebar) -->
            <div class="text-center d-none d-md-inline">
                <button class="rounded-circle border-0" id="sidebarToggle"></button>
            </div>


            <!-- Sidebar Message 
            <div class="sidebar-card">
                <img class="sidebar-card-illustration mb-2" src="img/undraw_rocket.svg" alt="">
                <p class="text-center mb-2"><strong>SB Admin Pro</strong> is packed with premium features, components, and more!</p>
                <a class="btn btn-success btn-sm" href="https://startbootstrap.com/theme/sb-admin-pro">Upgrade to Pro!</a>
            </div>
        -->

        </ul>
        <!-- End of Sidebar -->

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">

                

                <!-- Topbar -->
                <nav class="navbar navbar-expand topbar mb-4 static-top shadow" style="background-color: red;">


                    <!--imej PARC dalam top bar-->
                    <div class="container">
                        <img style="width: 100px; height: 50px;" src="img/linux.jpeg" >
                    
                        <img style="width: 100px; height: 50px;" src="img/parc3.jpeg">

                        <img style="width: 100px; height: 50px;" src="img/parc1.jpg">
                </div>

                </nav>

                

        <!-- Begin Page Content -->
        <div class="container-fluid">

            <!-- Page Heading 
            <h1 class="h3 mb-2 text-gray-800">Tables</h1>
            <p class="mb-4">DataTables is a third party plugin that is used to generate the demo table below.
                For more information about DataTables, please visit the <a target="_blank"
                    href="https://datatables.net">official DataTables documentation</a>.</p>
            -->

            <!-- DataTales Example -->
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">Maklumat Pemohon</h6>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                            <thead>
                                <tr>
                                <th style="text-align:center;">Bil</th>
                                    <th style="text-align:center;">Daftar</th>
                                    <th style="text-align:center;">Nama</th>
                                    <th style="text-align:center;">Umur</th>
                                    <th style="text-align:center;">Nombor Telefon</th>
                                    <th style="text-align:center;">Model Laptop</th>
                                    <th style="text-align:center;">Proccessor</th>
                                    <th style="text-align:center;">RAM</th>
                                    <th style="text-align:center;">Kursus</th>
                                    <th style="text-align:center;">Hari</th>
                                    <th style="text-align:center;">Masa</th>
                                    <th style="text-align:center;">Tarikh Permohonan</th>
                                    <th style="text-align:center;">Kemaskini</th>
                                </tr>
                            </thead>
                            <?php 
                                include 'connection.php';
                                $bil = 1;

                                $id = $_SESSION['id'];
                                $id = mysqli_real_escape_string($conn, $id);
                                $query = "SELECT * FROM permohonan WHERE id='$id'";
                                $result = mysqli_query($conn, $query);
                                while($row = mysqli_fetch_array($result)) {

                                
                               
                            ?>
                                    
                                
                                <tr>
                                    <td style="text-align:center;"><?php echo $bil++; ?></td>
                                    <td style="text-align:center;"><?php echo $row['id']; ?></td>
                                    <td style="text-align:center;"><?php echo $row['nama']; ?></td>
                                    <td style="text-align:center;"><?php echo $row['umur']; ?></td>
                                    <td style="text-align:center;"><?php echo $row['telefon']; ?></td>
                                    <td style="text-align:center;"><?php echo $row['model_laptop']; ?></td>
                                    <td style="text-align:center;"><?php echo $row['pro']; ?></td>
                                    <td style="text-align:center;"><?php echo $row['ram']; ?></td>
                                    <td style="text-align:center;"><?php echo $row['kursus']; ?></td>             
                                    <td style="text-align:center;"><?php echo $row['hari']; ?></td>
                                    <td style="text-align:center;"><?php echo $row['masa']; ?></td>
                                    <td style="text-align:center;"><?php echo date('d-m-y h:i:sa', strtotime($row['tarikh_permohonan'])); ?></td>
                                    <td style="text-align:center;">
                                    <span class="icon-block"><a href="kemaskini.php?id=<?php echo $id;?>"><i class="fa fa-edit"></i></a></span>
                                    </td>
                                </tr>
                              <?php
                                }
                                ?>
                        </table>
                    </div>
                </div>
            </div>

        </div>
        <!-- /.container-fluid -->

    </div>
    <!-- End of Main Content -->

    <!-- Footer -->
    <footer class="sticky-footer bg-white">
        <div class="container my-auto">
            <div class="copyright text-center my-auto">
                <span>Copyright &copy; ZULKIFLI 2021</span>
            </div>
        </div>
    </footer>
    </div>
</div>
    <!-- End of Footer -->
                

    <!-- Bootstrap core JavaScript-->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Core plugin JavaScript-->
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

    <!-- Custom scripts for all pages-->
    <script src="js/sb-admin-2.min.js"></script>

    <!-- Page level plugins -->
    <script src="vendor/chart.js/Chart.min.js"></script>

    <!-- Page level custom scripts -->
    <script src="js/demo/chart-area-demo.js"></script>
    <script src="js/demo/chart-pie-demo.js"></script>

     <!-- Page level plugins -->
     <script src="vendor/datatables/jquery.dataTables.min.js"></script>
     <script src="vendor/datatables/dataTables.bootstrap4.min.js"></script>

    <!-- Page level custom scripts -->
    <script src="js/demo/datatables-demo.js"></script>


</body>
</html>